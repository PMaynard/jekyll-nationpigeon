import pygame, sys
pygame.init()

if not pygame.font: print 'Warning, fonts disabled'

size = width,height = 320, 240
black = 255,255,255

screen = pygame.display.set_mode(size)
pygame.display.set_caption('Colour')

def enter():
	print 'Enter three numbers between 0 and 255'
	x = input('One: ')
	if x < 0 or x > 255:
		print 'Ivalid input'
		return(black)

	y = input('Two: ')
	if y < 0 or y > 255:
		print 'Ivalid input'
		return(black)

	z = input('Three: ')
	if z < 0 or z > 255:
		print 'Ivalid input'
		return(black)

	return x,y,z
def addText():
	#Put Text On The Background, Centered
	    if pygame.font:
		font = pygame.font.Font(None, 22)
		text = font.render("Enter a number between 0 and 255", 1, (255, 255, 255))
		textpos = text.get_rect( (size[0] + size[1]) )
		screen.blit(text, textpos)

def main():
	addText()

	while 1:
		for event in pygame.event.get():
			if event.type == pygame.QUIT: sys.exit()
 
		if raw_input("Run(y/n): ") == 'y':
			screen.fill( enter() )
		else:
			sys.exit()
		pygame.display.flip()

if __name__ == "__main__": main()
