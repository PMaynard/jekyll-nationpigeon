import os, pygame, sys
from pygame.locals import *
pygame.init()

size = width,height = 500,500
screen = pygame.display.set_mode(size)
black = 0, 0, 0
white = 255, 255, 255
height = 20

screen.fill(black)
pygame.display.flip()

x = xStart = size[0]/2
y = yStart = size[1]/2

def left():

	print 'l'


def draw():
	screen.fill(black)
	pygame.draw.rect(screen, (55, 55, 50), (x, y, height, 100))
	pygame.display.flip()

while 1:
	for event in pygame.event.get():
		if event.type == pygame.QUIT: sys.exit()
		if event.type == KEYDOWN and event.key == K_ESCAPE: sys.exit()
		if event.type == KEYDOWN and event.key == K_LEFT: left()

	draw()	

