import pygame, sys
pygame.init()

size = w,h = 320, 240
speed = [1,1]
black = 0,0,0

screen = pygame.display.set_mode(size)

gir = pygame.image.load("data/gir.jpg")
gir = gir.convert()

girrect = gir.get_rect()

while 1:
	for event in pygame.event.get():
		if event.type == pygame.QUIT: sys.exit()
	
	girrect = girrect.move(speed)

	if girrect.left < 0 or girrect.right > w:
		speed[0] = -speed[0]
	if girrect.top < 0 or girrect.bottom > h:
		speed[1] = -speed[1]

	screen.fill(black)
	screen.blit(gir, girrect)
	pygame.display.flip()
