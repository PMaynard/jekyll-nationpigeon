import java.net.*;
import javax.swing.*;
import java.awt.*;


class SwingWindow extends JFrame{

	public SwingWindow(){

		super("IP addy Mate");
		setSize(300, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		Container contentArea = getContentPane();
		contentArea.setBackground(Color.white);

		//Text and TextFields


	}
}

public class ipAddyMate{
	public static void main(String[] args){
		SwingWindow mian = new SwingWindow();
	}
}