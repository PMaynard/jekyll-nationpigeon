//Craeted By : Peter Maynard 
//Created On : 24 Jan 2008
//Description : 
// Finds the IP address of a domain name e.g www.google.com - 64.233.183.99

import java.net.*; // Imports the Network Package

public class domainIP{
	
	public static void main (String[] args){

		try{

			InetAddress inet = InetAddress.getByName("www.google.com");
			System.out.println ("IP  : " + inet.getHostAddress());

		}catch(UnknownHostException e){
			System.out.println("Error with connecting to hostname");
		}finally{
			System.out.println("Completed!");
		}// Ends finally

	}// Ends the Main Method

}// Ends Class LocalIP