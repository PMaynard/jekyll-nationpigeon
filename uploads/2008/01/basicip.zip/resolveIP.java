//Craeted By : Peter Maynard 
//Created On : 24 Jan 2008
//Description : 
// Finds the Hostname of an IP address e.g 66.249.93.104 - ug-in-f104.google.com

import java.net.*; // Imports the Network Package

public class resolveIP {

	public static void main(String[] args){

		try{
			InetAddress inet = InetAddress.getByName("66.249.93.104");
			System.out.println ("Host: " + inet.getHostName());

		}catch(UnknownHostException e){

			System.out.println("Unable to resolve IP address");

		}finally{

			System.out.println("End!");

		} // Ends the finally thingy (this will always happen)

	}// Ends the Main method 
}// Ends Class resolveIP 