//Craeted By : Peter Maynard 
//Created On : 24 Jan 2008
//Description : 
// Uses an Argument

import java.net.*; // Imports the Network Package

public class userInputIP{
	
	public static void main (String[] args){

		try{

			InetAddress inet = InetAddress.getByName(args[0]);
			System.out.println ("IP  : " + inet.getHostAddress());

		}catch(UnknownHostException e){
			System.out.println("Error with connecting to hostname");
		}finally{
			System.out.println("Completed!");
		} // Ends the finally thingy (this will always happen)

	}// Ends the Main method 
}// Ends Class resolveIP 