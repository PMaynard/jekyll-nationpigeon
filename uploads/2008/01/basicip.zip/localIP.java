//Craeted By : Peter Maynard 
//Created On : 24 Jan 2008
//Description : 
// Find the local IP address of the computer.

import java.net.*; // Imports the Network Package

public class localIP {
	public static void main (String[] in){
	
		try{
			InetAddress local = InetAddress.getLocalHost();

			// Print address	
			System.out.println ("Local IP : " + local.getHostAddress());

		}catch(UnknownHostException e){

			System.out.print("Unable to find your local IP address!");	

		}// Ends catch

	}// Ends the Main Method

}// Ends Class LocalIP